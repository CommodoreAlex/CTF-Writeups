 Web-LOG? We-BLOG? Webel-OGG? No idea how this one is pronounced. It's on the web, it's a log, it's a web-log, it's a blog. Just roll with it.

  <br><br>
  The challenge source code is available in the challenge.zip folder. The password is <code>snyk-ftf-2025</code>.

  <br><br>
  Use the Dockerfile to run a local instance of the challenge! To build and the container, unzip the contents of the challenge.zip file and run:

  <br><code>docker build -t [challenge_name] . && docker run -it -p 5000:5000 [challenge_name]</code>

  <br><br>

  <b>Press the <code>Start</code> button on the top-right to begin this challenge.</b>